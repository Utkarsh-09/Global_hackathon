import psycopg2

# Establish a connection to the PostgreSQL database
conn = psycopg2.connect(
    database="postgres",
    user="postgres",
    password="admin",
    host="127.0.0.1",
    port="5432"
)

# Create a cursor object to interact with the database
cur = conn.cursor()

# Initialize variables
total_premium_amount = 0
record_count = 0
switch_variable = 'N'

# Fetch policy data from DB2 tables
def fetch_policy_data():
    # Replace this with your actual data retrieval logic
    # Example: Fetch data from PostgreSQL tables and store it in policy_data_list
    select_query = """
        SELECT *
        FROM policy_records
        LIMIT 10;
        """
    cur.execute(select_query)
    policy_data_list = cur.fetchall()
    return policy_data_list

# Sort policy data
def sort_policy_data(policy_data_list):
    return sorted(policy_data_list, key=lambda x: x[0])  # Sorting based on Policy-Number

# Calculate total premium amount
def calculate_total_premium(policy_data_list):
    total_premium = sum(item[5] for item in policy_data_list)  # Sum of Policy-Premium
    return total_premium

# Generate policy summary report
def generate_policy_report(policy_data_list):
    # Generate the PolicyReportRecord and PolicySummaryReport
    policy_report_records = []
    total_policies = len(policy_data_list)
    total_claims = 0
    total_rejected_claims = 0

    for policy_data in policy_data_list:
        #policy_number, policy_holder_name, _, policy_type, coverage_limits, policy_premium, claim_status = policy_data
        policy_number= policy_data[0]
        policy_holder_name= policy_data[1]
        policy_type= policy_data[3]
        coverage_limits=policy_data[4]
        policy_premium=policy_data[5]
        claim_status= policy_data[10]

        # Calculate other fields (Age, Car-Value, Property-Type, Property-Value, Coverage-Amount) here

        # Update total claims and rejected claims count
        if claim_status == "CLAIMED":
            total_claims += 1
            if coverage_limits == 0:
                total_rejected_claims += 1

        policy_report_records.append((
            policy_number, policy_type, policy_holder_name,
            coverage_limits, policy_premium, claim_status,
            0, 0, "", 0, 0  # Placeholder for Age, Car-Value, Property-Type, Property-Value, Coverage-Amount
        ))

    return policy_report_records, total_policies, total_claims, total_rejected_claims

# Write the report to a file (PolicyIMSFile)
def write_report_to_file(policy_report_records):
    with open('POLICYIMS.DAT', 'w') as f:
        for record in policy_report_records:
            policy_data_ims = ','.join(str(field) for field in record)
            f.write(policy_data_ims + '\n')

# Main procedure
def main():
    policy_data_list = fetch_policy_data()
    sorted_policy_data = sort_policy_data(policy_data_list)
    total_premium_amount = calculate_total_premium(sorted_policy_data)
    print("sorted_policy_data", sorted_policy_data)
    policy_report_records, total_policies, total_claims, total_rejected_claims = generate_policy_report(sorted_policy_data)
    write_report_to_file(policy_report_records)

    # Print summary report
    print("Total Policies:", total_policies)
    print("Total Premiums:", total_premium_amount)
    print("Total Claims:", total_claims)
    print("Total Rejected Claims:", total_rejected_claims)

    # Close the database connection
    cur.close()
    conn.close()

if __name__ == "__main__":
    main()
